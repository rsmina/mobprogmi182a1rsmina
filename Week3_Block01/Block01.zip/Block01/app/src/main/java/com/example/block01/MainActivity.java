package com.example.block01;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button blueButton, pinkButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Typeface productSans = getResources().getFont(R.font.product_sans_bold);

        blueButton = (Button) findViewById(R.id.man);
        blueButton.setOnClickListener(this);

        pinkButton = new Button(this);
        pinkButton.setTypeface(productSans);
        pinkButton.setId(R.id.panther_button);
        pinkButton.setTextColor(Color.parseColor("#FFFFFF"));
        pinkButton.setBackgroundColor(Color.parseColor("#CA98C1"));
        pinkButton.setText(R.string.second_button);
        pinkButton.setOnClickListener(this);

        ConstraintLayout layout = (ConstraintLayout) findViewById(R.id.main_screen);
        layout.addView(pinkButton);
        ConstraintSet set = new ConstraintSet();
        set.clone(layout);

        set.constrainWidth(pinkButton.getId(), ConstraintSet.MATCH_CONSTRAINT);
        set.constrainHeight(pinkButton.getId(), ConstraintSet.WRAP_CONTENT);
        set.centerHorizontally(pinkButton.getId(), layout.getId());
        set.connect(pinkButton.getId(), ConstraintSet.TOP, blueButton.getId(), ConstraintSet.BOTTOM, 8);
        set.connect(pinkButton.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT, 0);
        set.connect(pinkButton.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT, 0);
        set.applyTo(layout);
    }

    public void todo(View view) {
        if(view.equals(blueButton)) {
            view.setVisibility(View.INVISIBLE);
        }
        if(view.equals(pinkButton)) {
            Toast.makeText(getApplicationContext(),
                    "to do to do to do",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View view) {
        todo(view);
    }
}

